class SSHConnectionError(Exception):
    pass

class FileUploadError(Exception):
    pass

class ParameterValidationError(Exception):
    pass